package main

import "github.com/coredns/deployment/kubernetes/corefile-tool/cmd"

func main() {
	cmd.Execute()
}
